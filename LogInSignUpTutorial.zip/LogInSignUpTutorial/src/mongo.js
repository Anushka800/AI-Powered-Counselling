// const mongoose=require("mongoose")

// mongoose.connect("mongodb://localhost:27017/LoginSignUpTutorial")
// .then(()=>{
//     console.log('mongoose connected');
// })
// .catch((e)=>{
//     console.log('failed');
// })

// const logInSchema=new mongoose.Schema({
//     name:{
//         type:String,
//         required:true
//     },
//     password:{
//         type:String,
//         required:true
//     }
// })

// const LogInCollection=new mongoose.model('LogInCollection',logInSchema)

// module.exports=LogInCollection

const mongoose = require("mongoose");

// Connect to MongoDB database
mongoose.connect("mongodb://localhost:27017/LoginSignUpTutorial", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverSelectionTimeoutMS: 5000, // Increase timeout to 5 seconds
})
.then(() => {
    console.log('Mongoose connected');
})
.catch((error) => {
    console.error('Failed to connect to MongoDB:', error);
});

// Define schema
const logInSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }
});

// Create model
const LogInCollection = mongoose.model('LogInCollection', logInSchema);

module.exports = LogInCollection;
